Imports System

Module Program
    Sub Main()

        'Calcular el pago por galones de gasolina de una estaci�n de servicio, seg�n el tipo de gasolina
        'Gasolina Premium Extra: 1 litro: 5.000 pesos
        'Gasolina Premium: 1 litro: 3.900 pesos
        'Gasolina Corriente: 1 litro 3.200 pesos
        'Se debe mostrar la cantidad de gasolina expresada en galones y litros, el cliente pide en galones.

        Dim opt As Integer
        Dim gal As Decimal
        Dim lit As Decimal
        Dim valor As Decimal

        Dim constL As Decimal = 3.78541


        Console.WriteLine("�Qu� cantidad en galones desea?")
        gal = Console.ReadLine()

        Console.WriteLine("�Qu� obcion desea: ")
        Console.WriteLine("1. Gasolina Premium Extra: 1 litro: 5.000 pesos")
        Console.WriteLine("2. Gasolina Premium: 1 litro: 3.900 pesos")
        Console.WriteLine("3. Gasolina Corriente: 1 litro 3.200 pesos")
        opt = Console.ReadLine()


        Select Case opt

            Case 1

                Console.WriteLine("Gasolina Premium Extra: 1 litro: 5.000 pesos")
                Console.WriteLine("La cantidad pedida fue: " & gal & " Galones")

                lit = gal * constL
                Console.WriteLine("La cantidad en litros es: " & lit & " Litros")

                valor = lit * 5000
                Console.WriteLine("La cantidad a pagar es: " & valor & " Pesos")

            Case 2

                Console.WriteLine("Gasolina Premium: 1 litro: 3.900 pesos")
                Console.WriteLine("La cantidad pedida fue: " & gal & " Galones")

                lit = gal * constL
                Console.WriteLine("La cantidad en litros es: " & lit & " Litros")

                valor = lit * 3900
                Console.WriteLine("La cantidad a pagar es: " & valor & " Pesos")

            Case 3

                Console.WriteLine("Gasolina Corriente: 1 litro 3.200 pesos")
                Console.WriteLine("La cantidad pedida fue: " & gal & " Galones")

                lit = gal * constL
                Console.WriteLine("La cantidad en litros es: " & lit & " Litros")

                valor = lit * 3200
                Console.WriteLine("La cantidad a pagar es: " & valor & " Pesos")

        End Select

    End Sub
End Module