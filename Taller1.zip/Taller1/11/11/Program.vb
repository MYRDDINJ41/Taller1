Imports System

Module Program
    Sub Main()

        Dim n1 As Decimal
        Dim n2 As Decimal
        Dim n3 As Decimal
        Dim resultado As Decimal

        Console.WriteLine("Por favor ingrese 3 numeros impares para la suma")

        n1 = Console.ReadLine()
        n2 = Console.ReadLine()
        n3 = Console.ReadLine()

        If (n1 Mod 2 <> 0) And (n2 Mod 2 <> 0) And (n3 Mod 2 <> 0) Then

            resultado = n1 + n2 + n3
            Console.WriteLine("El resultado es: " & resultado)

        Else
            Do
                Console.WriteLine("Algun numero no es impar, vuelva he intente")
                n1 = Console.ReadLine()
                n2 = Console.ReadLine()
                n3 = Console.ReadLine()

            Loop Until (n1 Mod 2 <> 0) And (n2 Mod 2 <> 0) And (n3 Mod 2 <> 0)

            resultado = n1 + n2 + n3
            Console.WriteLine("El resultado es: " & resultado)

        End If

    End Sub
End Module
