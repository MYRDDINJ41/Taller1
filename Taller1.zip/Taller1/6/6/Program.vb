Imports System

Module Program
    Sub Main()

        'Calcular el monto a pagar por el servicio de internet seg�n el nivel del cliente y la cantidad de MB:


        'Canda MB tiene un precio de: 
        'Nivel 1 : 5000 pesos
        'Nivel 2 : 7000 pesos
        'Nivel 3 : 9000 pesos
        'Nivel 4 : 15000 pesos
        'Nivel 5 : 22000 pesos
        'Nivel 6 : 30000 pesos
        'Todos los dem�s niveles 35000 pesos




    End Sub
End Module
