Imports System

Module Program
    Sub Main()

        'Realizar un algoritmo que permita dar una poderacion cualitativa, seg�n una nota cuantitativa: 

        Dim nota As Integer


        Console.WriteLine("Ingrese la nota para uan ponderaci�n cualitativa")
        nota = Console.ReadLine()


        If (nota >= 0 And nota <= 40) Then
            Console.WriteLine("P�simo, Aplazado sin oportunidad")
        ElseIf (nota >= 41 And nota <= 45) Then
            Console.WriteLine("Deficiente, Aplazado a reparaci�n")
        ElseIf (nota >= 46 And nota <= 50) Then
            Console.WriteLine("Bajo, Aplazado repetir examen")
        ElseIf (nota >= 51 And nota <= 60) Then
            Console.WriteLine("Regular, No aplazado � Remedial")
        ElseIf (nota >= 61 And nota <= 70) Then
            Console.WriteLine("Bien")
        ElseIf (nota >= 71 And nota <= 80) Then
            Console.WriteLine("Muy bien")
        ElseIf (nota >= 81 And nota <= 100) Then
            Console.WriteLine("Excelente")
        End If

    End Sub
End Module
