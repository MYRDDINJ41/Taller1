Imports System

Module Program
    Sub Main()

        'Calcular el inter�s a pagar por un dinero, colocado a generar inter�s diario.
        'se debe ingresar la cantidad de dinero, los d�as que lleva generando inter�s
        'y el inter�s. Se debe imprimir el inter�s y la cantidad de dinero m�s el inter�s.

        Dim interes As Decimal = (0.03)
        Dim dinero As Decimal
        Dim dias As Integer
        Dim dinInt As Decimal
        Dim toDias As Decimal

        Console.WriteLine("Ingrese el valor que desea retirar")
        dinero = Console.ReadLine()

        Console.WriteLine("Ingrese los d�as por los que adquirira el prestamo")
        dias = Console.ReadLine

        interes = dinero * (interes)
        Console.WriteLine("El interes por d�a es: " & interes & " Pesos")

        toDias = interes * dias
        Console.WriteLine("El total de interes por los dias es: " & toDias & " Pesos")

        dinInt = toDias + dinero
        Console.WriteLine("El total a pagar depues de los " & dias & " dias es: " & dinInt & " Pesos")

    End Sub
End Module
