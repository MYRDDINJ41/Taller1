Imports System

Module Program
    Sub Main()

        'calcular el cuadrado de un nuemro entero ingresado por el usuario solo si, el numero es multipo  de 4 y 16

        Dim num As Integer

        Console.WriteLine("Ingrese un nuemro entero multiplo de 4")
        num = Console.ReadLine()


        If (num Mod 4 = 0) And (num > 0) Then

            num ^= 2
            Console.WriteLine("El total es: " & num)

        Else
            Do

                Console.WriteLine("El numero inresado no era entero ni multiplo de 4, vuelva e ingrese el numero")
                num = Console.ReadLine()

            Loop Until (num Mod 4 = 0) And (num > 0)


            num ^= 2
            Console.WriteLine("El total es: " & num)

        End If

    End Sub
End Module
