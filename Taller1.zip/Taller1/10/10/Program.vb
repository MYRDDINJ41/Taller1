Imports System

Module Program
    Sub Main()
        'Realizar un pseudoc�digo que sume 3 n�meros e imprimir la suma

        Dim n1 As Decimal
        Dim n2 As Decimal
        Dim n3 As Decimal
        Dim resultado As Decimal


        Console.WriteLine("Ingrese tres numeros para realizar la suma")

        n1 = Console.ReadLine()
        n2 = Console.ReadLine()
        n3 = Console.ReadLine()

        resultado = n1 + n2 + n3

        Console.WriteLine("El total de la suma es: " & resultado)
    End Sub
End Module
