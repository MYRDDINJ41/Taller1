Imports System

Module Program
    Sub Main()

        'leer dos numeros y determinar �cual es positivo?

        Dim n1 As Decimal
        Dim n2 As Decimal

        Console.WriteLine("Ingrese un numero negativo o positivo")
        n1 = Console.ReadLine

        Console.WriteLine("Vuelva he ingrese un numero positivo o negativo")
        n2 = Console.ReadLine

        If n1 > 0 Then
            Console.WriteLine("El numero " & n1 & " es un numero positivo")
        Else
            Console.WriteLine("El numero " & n2 & " es un numero positivo")
        End If

    End Sub
End Module
