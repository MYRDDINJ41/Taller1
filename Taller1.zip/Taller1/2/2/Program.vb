Imports System

Module Program
    Sub Main()
        'calcular el cubo de un n�mero entero ingresado por el usuario solo si, el n�mero es multipo de 3 y 5.

        Dim n As Integer


        Console.WriteLine("Ingrese un n�mero entero que sea multiplo de 3")
        n = Console.ReadLine()

        'If (n > 0) And (n Mod 3 = 0) Then

        'n ^= 3
        'Console.WriteLine("El resultado es: " & n)

        'Else

        'Console.WriteLine("El n�mero ingresado no es entero, ingrese nuevamente un numero entero y multiplo de 3 y 5")
        'n = Console.ReadLine()

        'If (n > 0) And (n Mod 3 = 0) Then

        'n ^= 3
        'Console.WriteLine("El resultado es: " & n)

        'Else

        'End If
        'End If

        If (n > 0) And (n Mod 3 = 0) Then
            n ^= 3
            Console.WriteLine("El resultado es: " & n)
        Else
            Do
                Console.WriteLine("El numero no era entero o multiplo de 3, ingrese nuevamente")
                n = Console.ReadLine()

            Loop Until (n > 0) And (n Mod 3 = 0)

            n ^= 3
            Console.WriteLine("El resultado es: " & n)

        End If

    End Sub
End Module
