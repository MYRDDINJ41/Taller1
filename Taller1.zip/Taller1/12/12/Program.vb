Imports System

Module Program
    Sub Main()
        'Dado una compra realizada calcular: El iva e imprimir: la compra sin iva, el iva en pesos y el monto con el iva. Tomar en cuenta que el iva es el 19%

        Dim iva As Decimal = 0.19
        Dim compra As Decimal
        Dim tCompra As Decimal
        Dim tiva As Decimal

        Console.WriteLine("Coloque el monto a pagar")
        compra = Console.ReadLine()

        Console.WriteLine("El total de la compra es: " & compra)

        tiva = compra * iva
        Console.WriteLine("El total del impuesto es: " & tiva)

        tCompra = compra + tiva
        Console.WriteLine("El total con el iva es: " & tCompra)


    End Sub
End Module
