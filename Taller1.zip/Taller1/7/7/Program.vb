Imports System

Module Program
    Sub Main()
        'Calcular el sueldo a pagar de un trabajador dado que se debe ingresar la cantidad de horas trabajadas y el valor de la hora en pesos

        Dim salario As Integer
        Dim horas As Integer

        Dim pxh As Integer = 7000

        Console.WriteLine("Coloque sus horas tabajadas")
        horas = Console.ReadLine()
        salario = horas * pxh
        Console.WriteLine("Su salaio es: " & salario & " Pesos")


    End Sub
End Module
