Imports System

Module Program
    Sub Main()

        Dim n1 As Decimal

        Console.WriteLine("Digite su n�mero para saber si es par y positivo")
        n1 = Console.ReadLine()

        If (n1 Mod 2 = 0) Then
            Console.WriteLine("El n�mero es par")
        Else
            Console.WriteLine("El n�mero es impar")
        End If

        If (n1 > 0) Then
            Console.WriteLine("El n�mero es positivo")
        Else
            Console.WriteLine("El n�mero es negativo")
        End If

    End Sub
End Module
